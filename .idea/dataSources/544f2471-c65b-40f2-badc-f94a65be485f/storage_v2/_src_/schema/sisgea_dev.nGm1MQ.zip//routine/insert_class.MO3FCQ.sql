create
    definer = root@localhost procedure insert_class(IN p_name varchar(45), IN p_program_id int, IN p_status tinyint)
BEGIN
    DECLARE count_rows INT;
    DECLARE rollback_action BOOL DEFAULT 0;

    -- Iniciar la transacción
    START TRANSACTION;

    -- Verificar si ya existe una combinación de nombre de clase y program_id
    SELECT COUNT(*) INTO count_rows
    FROM class
    WHERE name = p_name
      AND program_id = p_program_id;

    -- Si count_rows es mayor que 0, hacer rollback y enviar un mensaje de error
    IF count_rows > 0 THEN
        SET rollback_action = 1;  -- Marcar para hacer rollback
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'repeated';
    ELSE
        -- Insertar el nuevo registro
        INSERT INTO class(name, program_id, status)
        VALUES(p_name, p_program_id, p_status);
    END IF;

    -- Comprobar si se debe hacer rollback o commit
    IF rollback_action THEN
        ROLLBACK;
    ELSE
        COMMIT;
    END IF;
END;

