create
    definer = root@localhost procedure update_schedule(IN p_schedule_id int, IN p_class_id int, IN p_quarter_id int,
                                                       IN p_room_id int,
                                                       IN p_day enum ('Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo'),
                                                       IN p_starttime time, IN p_endtime time)
BEGIN
    DECLARE v_count_same_class INT;
    DECLARE v_count_time_overlap INT;
    DECLARE continue_update BOOLEAN DEFAULT TRUE;

    START TRANSACTION;
    
    -- Verificar si ya existe un registro con los mismos datos exactos
    SELECT COUNT(*) INTO v_count_same_class
    FROM schedule
    WHERE class_id = p_class_id
      AND quarter_id = p_quarter_id
      AND room_id = p_room_id
      AND day = p_day
      AND starttime = p_starttime
      AND endtime = p_endtime;

    -- Verificar si hay traslape de horarios en el mismo cuatri, aula y día
    SELECT COUNT(*) INTO v_count_time_overlap
    FROM schedule
    WHERE schedule_id != p_schedule_id
      AND quarter_id = p_quarter_id
      AND room_id = p_room_id
      AND day = p_day
      AND (
          (p_starttime >= starttime AND p_starttime < endtime) OR
          (p_endtime > starttime AND p_endtime <= endtime) OR
          (p_starttime <= starttime AND p_endtime >= endtime)
      );

    -- Si se encuentra un registro idéntico, lanzar un error
    IF v_count_same_class > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'repeated';
        SET continue_update = FALSE;
    END IF;

    -- Si se encuentra un traslape de horario, lanzar un error
    IF v_count_time_overlap > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'conflict';
        SET continue_update = FALSE;
    END IF;

    -- Actualizar la clase si no hay conflictos ni duplicados
    IF continue_update THEN
        UPDATE schedule
        SET class_id = p_class_id,
            quarter_id = p_quarter_id,
            room_id = p_room_id,
            day = p_day,
            starttime = p_starttime,
            endtime = p_endtime
        WHERE schedule_id = p_schedule_id;
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
END;

