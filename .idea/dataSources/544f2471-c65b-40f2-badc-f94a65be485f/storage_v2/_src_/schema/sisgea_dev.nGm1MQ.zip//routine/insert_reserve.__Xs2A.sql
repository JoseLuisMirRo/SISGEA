create
    definer = root@localhost procedure insert_reserve(IN p_user_id int, IN p_room_id int, IN p_description int,
                                                      IN p_date date, IN p_starttime time, IN p_endtime time,
                                                      IN p_status tinyint)
BEGIN 
	DECLARE v_count_same_reserve INT;
    DECLARE V_count_time_overlap INT;
    DECLARE continue_insert BOOLEAN DEFAULT TRUE; 
    
    START TRANSACTION; 
    
    -- Verificar si ya existe una reserva con los mismos datos exactos Y ESTA ESTÁ ACTIVA
    SELECT COUNT(*) INTO v_count_same_reserve
    FROM reserve
    WHERE room_id = p_room_id
	  AND date = p_date
      AND starttime = p_starttime
      AND endtime = p_endtime
      AND status = true;
      
	SELECT COUNT(*) INTO v_count_time_overlap
    FROM reserve
    WHERE room_id = p_room_id
       AND date = p_date
       AND status = true
       AND (
          (p_starttime >= starttime AND p_starttime < endtime) OR
          (p_endtime > starttime AND p_endtime <= endtime) OR
          (p_starttime <= starttime AND p_endtime >= endtime)
      );
      
      -- Si se encuetra un registro idéntico, arrojar un error
      IF v_count_same_reserve > 0 THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'repeated';
		SET continue_insert = FALSE;
	  END IF;
      
      -- Si se encuentra un traslpa de horario, lanzar un error
      IF v_count_time_overlap > 0 THEN 
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'conflict';
        SET continue_insert = FALSE;
      END IF;
      
      -- Insertar la nueva reserva si no hay conflictos ni duplicados
      IF continue_insert THEN 
		INSERT INTO reserve (user_id,room_id,description,date,starttime,endtime,status)
        VALUES (p_user_id,p_room_id,p_date,p_starttime,p_endtime,p_status);
        COMMIT;
	ELSE
		ROLLBACK;
	END IF;
END;

