create
    definer = root@localhost procedure update_reserve_status(IN p_id int, IN p_status enum ('Active', 'Canceled', 'Admin_Canceled'))
BEGIN 
    DECLARE v_room_id INT;
    DECLARE v_date DATE;
    DECLARE v_starttime TIME;
    DECLARE v_endtime TIME;
    DECLARE v_count_same_reserve INT;
    DECLARE v_count_time_overlap INT;
    DECLARE continue_update BOOLEAN DEFAULT TRUE; 

    START TRANSACTION;

    -- Obtener los detalles de la reserva actual
    SELECT room_id, date, starttime, endtime INTO v_room_id, v_date, v_starttime, v_endtime
    FROM reserve
    WHERE id = p_id;

    -- Solo realizar verificaciones si el nuevo status es 'active'+
    IF p_status = 1 THEN
        -- Verificar si ya existe una reserva con los mismos datos exactos y está activa
        SELECT COUNT(*) INTO v_count_same_reserve
        FROM reserve
        WHERE room_id = v_room_id
            AND date = v_date
            AND starttime = v_starttime
            AND endtime = v_endtime
            AND status = 1
            AND id != p_id;

        -- Verificar si hay traslape de horario con otras reservas activas
        SELECT COUNT(*) INTO v_count_time_overlap
        FROM reserve
        WHERE room_id = v_room_id
            AND date = v_date
            AND status = 1
            AND id != p_id
            AND (
                (v_starttime >= starttime AND v_starttime < endtime) OR
                (v_endtime > starttime AND v_endtime <= endtime) OR
                (v_starttime <= starttime AND v_endtime >= endtime)
            );

        -- Si se encuentra un registro idéntico, arrojar un error
        IF v_count_same_reserve > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'repeated';
            SET continue_update = FALSE;
        END IF;

        -- Si se encuentra un traslape de horario, lanzar un error
        IF v_count_time_overlap > 0 THEN 
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'conflict';
            SET continue_update = FALSE;
        END IF;
    END IF;

    -- Actualizar el status de la reserva si no hay conflictos
    IF continue_update THEN 
        UPDATE reserve 
        SET status = p_status
        WHERE id = p_id;
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
END;

