create
    definer = root@localhost procedure InsertarUsuarioConRol(IN p_email varchar(50), IN p_firstname varchar(50),
                                                             IN p_lastnamep varchar(45), IN p_lastnamem varchar(45),
                                                             IN p_password varchar(60), IN p_status tinyint,
                                                             IN p_role_id int)
BEGIN
    DECLARE v_user_id INT;

    -- Insertar el usuario en la tabla 'user'
    INSERT INTO user (email, firstname, lastnamep, lastnamem, password, status)
    VALUES (p_email, p_firstname, p_lastnamep, p_lastnamem, p_password, p_status);

    -- Obtener el ID del usuario insertado
    SET v_user_id = LAST_INSERT_ID();

    -- Asignar el rol al usuario en la tabla 'userrole'
    INSERT INTO userrole (user_id, role_id)
    VALUES (v_user_id, p_role_id);

    -- Confirmar la transacción
    COMMIT;
END;

