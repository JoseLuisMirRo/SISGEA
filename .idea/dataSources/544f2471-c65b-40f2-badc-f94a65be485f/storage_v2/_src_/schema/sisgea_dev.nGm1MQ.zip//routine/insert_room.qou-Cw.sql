create
    definer = root@localhost procedure insert_room(IN p_roomtype_id int, IN p_building_id int, IN p_number int,
                                                   IN p_status int)
BEGIN
    DECLARE count_rows INT;
    DECLARE rollback_action BOOL DEFAULT 0;

    -- Iniciar la transacción
    START TRANSACTION;

    -- Verificar si el número ya existe para la combinación de roomtype_id y building_id
    SELECT COUNT(*) INTO count_rows
    FROM room
    WHERE roomtype_id = p_roomtype_id
      AND building_id = p_building_id
      AND number = p_number;

    -- Si count_rows es mayor que 0, hacer rollback y enviar un mensaje de error
    IF count_rows > 0 THEN
        SET rollback_action = 1;  -- Marcar para hacer rollback
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'A record with the same number already exists for this roomtype_id and building_id';
    ELSE
        -- Insertar el nuevo registro
        INSERT INTO room(roomtype_id, building_id, number, status)
        VALUES(p_roomtype_id, p_building_id, p_number, p_status);
    END IF;

    -- Comprobar si se debe hacer rollback o commit
    IF rollback_action THEN
        ROLLBACK;
    ELSE
        COMMIT;
    END IF;
END;

